$(document).ready(function() {
    $('#myCarousel').carousel({
	    interval: 10000
	})
});